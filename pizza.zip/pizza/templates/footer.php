
  <footer class="section">
    <div class="center grey-text">Copyright 2020 JBL pizzas</div>
  </footer>
</body>
